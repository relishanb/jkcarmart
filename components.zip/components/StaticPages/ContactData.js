export const ContactData = [
  {
    title: 'Address',
    content: 'PCI INFOTECH 2nd Floor, Shiva Complex, Opposite Lajwanti Hospital Greater Kailash, Main Highway Jammu - 180010 J&K (India)'
  }
];