import styles from "./NoRecordFound.module.css";
import { FaCar } from "react-icons/fa";
function NoRecordFound(props){
    return(
        <div className={styles.message}>
            <span className={styles.icon}><FaCar /></span>
            <h3 className={styles.heading}>{props.message.heading}</h3>
            </div>
    )
}
export default NoRecordFound;