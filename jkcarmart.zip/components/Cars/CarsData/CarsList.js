import CarInfo from "./CarInfo";
import SearchBoxLocations from "@/components/Layout/Header/SearchBoxLocations";
import styles from "./CarsList.module.scss";
import CarFilters from "../CarsFilters/FiltersList/CarFilters";


import { useGetAdsQuery } from "@/store/apiServices/apiServices";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";

import { filterNames,filterPositions,filterActions } from "@/store/filters";

import {FaMapMarkerAlt} from "react-icons/fa";

//let pageNumber = 1;
//let activeCarsList = [];

import CarsListAppliedFilters from "./CarsListAppliedFilters";

function CarsList() {

  const filtersData = useSelector(state=>state.filter.filterData);



//   useEffect(()=>{    
//     localStorage.clear();
// },[])


const [pageNumber,setPageNumber] = useState(1);
const [activeCarsList,setActiveCarsList] = useState([]);


// console.log("pageNumber"); 
//   console.log(pageNumber); 


let filterProperties = useSelector(state=>state.filter.filterParameters);
filterProperties = filterProperties.filterList;

// console.log("filterProperties");
// console.log(filterProperties);

const userDetails = useSelector(state=>state.filter.filterData[filterPositions[filterNames.User]][filterNames.User]);
//console.log("user Details"+userDetails);


if(filterProperties=="" || filterProperties==undefined) filterProperties = "(brandname<>'')";

//const [pageNumber,setPageNumber] = useState(1);


useEffect(()=>{    
  setPageNumber(1);
  setActiveCarsList([]);
},[filterProperties])

// useEffect(()=>{    
//   pageNumber = 1;
//   setActiveCarsList([]);
// },[])


// console.log("filterProperties");
// console.log(filterProperties);


  const {data,refetch} = useGetAdsQuery({
    filterList: [
      {
        "propertyName": filterProperties,
        "propertyVal": "",
        "operator": "",
        "conjuction": ""
      }
    ],
    paging: {
      "pageNumber": pageNumber,
      "pageLines": 9
    },
    sortList: [
      {
        "propertyName": "ci.createDate",
        "sortType": "desc"
      }
    ]
  });

// console.log("filterList");
// console.log(filterList);


  // console.log('data outer');
  // console.log(data);
 
  useEffect(()=>{    
    if(data) {     
      pageNumber > 1 ? setActiveCarsList(prev=>[...prev, ...data]) : setActiveCarsList(data);
    };
  },[data])

  //if(data) activeCarsList = [...activeCarsList , ...data];

  // console.log("activeCarsList");
  // console.log(activeCarsList);

const dispatch = useDispatch();
function clearUser(){
  dispatch(filterActions.clearFilter(filterNames.User));
}


function showMoreCars(){

  //console.log("showMoreCars");
  //setPageNumber(prev=>prev+1);
  setPageNumber(prev=>prev+1);
  refetch();
}

  return (

    <>

<section className="first_section">
  <div className="container mt-20 md:mt-40">

    <div className={styles.cars_section}>
    
      <CarFilters />


      <div className={styles.cars_list}>

{userDetails && userDetails!="" &&
      <div className={styles.user_details}>       
       <span>Cars from <span className={styles.name}>{userDetails[1]}</span></span>
        <span title="Clear Dealer Filter" className={styles.clear_user} onClick={clearUser}>Clear</span>
        </div>}

<div className={styles.list_header}>
<h3 className={styles.ad_list_title}>
        <span>{activeCarsList[0]?activeCarsList[0].totalCars:0} Used Cars</span>
        <span> For Sale</span>
      </h3>
<div className="menu location">
<i className="icon">
                    <FaMapMarkerAlt />
                  </i>
  <SearchBoxLocations />
  </div>
</div>
      

<CarsListAppliedFilters filtersData={filtersData}/>
      

      <div className={styles.ad_list}>
        { activeCarsList?.map((element,index) => {   

return <CarInfo carInfo={element} key={element.carId} />        

        })}
      </div>

{activeCarsList?.length > 0 &&
      <div className={styles.ad_view_more}>
        <div className={styles.ad_show_count}>Showing {activeCarsList?.length} of {activeCarsList[0]?.totalCars} Cars</div>

        {activeCarsList?.length < activeCarsList[0]?.totalCars && 
        <div className={styles.ad_show_more}>
          <a onClick={showMoreCars} className="btn btn_border_primary cars_list_load_more_cars">
           Show More Cars
          </a>
        </div>
      }

      </div>
}

</div>




    </div>

    </div>
</section>

<section className="bg_white">
  <div className="container">
  <div className="sec-heading">
          <h2>
          Buy Used Cars in Jammu
          </h2>
        </div>
        <p>
        Are you in the market for a reliable used car in Jammu? JK Carmart is the answer.
        </p>
        <p>
        Find top-notch 2nd handcars in Jammu with one of the best site to sell car without the hassle. Explore our comprehensive best used car platform on how to buy used cars in Jammu.
        </p>
        <p><strong>Here is How to Buy Used Cars?</strong></p>
          <ul className="list_dotted">
            <li><strong>Filter &amp; Search:</strong> Explore our extensive listings of used cars in jammu to find your dream car.</li>
            <li><strong>Contact:</strong> Connect directly with sellers for second hand cars in jammu via verified mobile numbers.</li>
            <li><strong>Deal:</strong> Arrange a meeting, inspect the car, and close the deal in person and get value car mart.</li>
          </ul>
  </div>
</section>

</>

  );
}
export default CarsList;
