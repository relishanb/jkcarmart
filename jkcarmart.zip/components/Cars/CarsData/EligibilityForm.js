import React, { useState } from 'react';
import Button from '@/components/UI/UIcomponents/Button';
import { usePostDataMutation } from '@/store/apiServices/apiServices';
import { FiLoader } from 'react-icons/fi';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export const EligibilityForm = ({ closeModal, carId }) => {
  const [formData, setFormData] = useState({
    carid: carId,
    fullname: '',
    birthyear: '',
    mobileno: '',
    emailid: '',
    employmenttype: '',
    monthlyincome: '',
    employmentduration: '',
    durationunit: 'Months',
  });

  const [postData, { isLoading }] = usePostDataMutation();

  const handleChange = (e) => {
    const { name, value } = e.target;

    // Format monthly income with commas
    if (name === 'monthlyincome') {
      const formattedValue = formatToIndianCurrency(value);
      setFormData((prevData) => ({
        ...prevData,
        [name]: formattedValue,
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };

  const formatToIndianCurrency = (value) => {
    const numericValue = value.replace(/,/g, '').replace(/\D/g, '');
    return numericValue.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  };

  const validateForm = () => {
    const {
      fullname,
      birthyear,
      mobileno,
      emailid,
      employmenttype,
      monthlyincome,
      employmentduration,
    } = formData;
  
    // Check if all fields are filled
    if (
      !fullname ||
      !birthyear ||
      !mobileno ||
      !emailid ||
      !employmenttype ||
      !monthlyincome ||
      !employmentduration
    ) {
      toast.error('Please fill all the fields.');
      return false;
    }
  
    // Check if full name contains only letters and spaces
    if (!/^[a-zA-Z ]+$/.test(fullname)) {
      toast.error('Full name must only contain letters and spaces.');
      return false;
    }
  
    // Check if user is at least 15 years old
    const currentYear = new Date().getFullYear();
    const birthYear = new Date(birthyear).getFullYear();
    if (currentYear - birthYear < 15) {
      toast.error('You must be at least 15 years old.');
      return false;
    }
  
    // Validate mobile number format
    if (!/^\d{10}$/.test(mobileno)) {
      toast.error('Mobile number must be 10 digits.');
      return false;
    }
  
    // Validate email format
    if (!/^[^@\s]+@[^@\s]+\.com$/.test(emailid)) {
      toast.error('Wrong Email Address.');
      return false;
    }
  
    // Validate employment type selection
    if (
      !['Govt. service', 'Private', 'Unemployed', 'Retired'].includes(
        employmenttype
      )
    ) {
      toast.error('Select a valid employment type.');
      return false;
    }
  
    // Validate monthly income format
    if (!/^\d+(\.\d+)?$/.test(monthlyincome.replace(/,/g, ''))) {
      toast.error('Monthly income must be a valid number.');
      return false;
    }
  
    // Validate employment duration format
    if (!/^[0-9]+$/.test(employmentduration)) {
      toast.error('Employment duration must be a number.');
      return false;
    }
  
    return true;
  };
  

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    // Perform validation
    if (!validateForm()) {
      return; // Stop submission if validation fails
    }
  
    try {
      const response = await postData({
        ...formData,
        monthlyincome: formData.monthlyincome.replace(/,/g, ''),
      }).unwrap();
  
      if (response.statusCode === '200') {
        toast.success(response.apiMessage);
        setTimeout(closeModal, 1000);
      } else {
        toast.error(response.error || 'An error occurred.');
      }
    } catch (error) {
      toast.error(error?.data?.message || 'Failed to submit. Please try again.');
    }
  };
  

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-75 flex justify-center items-center z-20"
      onClick={closeModal}
    >
      <ToastContainer position='top-center'/>
      <div
        className="bg-white p-6 rounded-lg shadow-lg max-w-sm"
        onClick={(e) => e.stopPropagation()}
      >
        <form onSubmit={handleSubmit}>
          <label className="block mb-2">
            Full Name
            <input
              type="text"
              name="fullname"
              value={formData.fullname}
              onChange={handleChange}
              placeholder="Enter your full name"
              className="w-full p-2 border rounded mt-1"
            />
          </label>
          <label className="block mb-2">
  Year of Birth
  <input
    type="date"
    name="birthyear"
    value={formData.birthyear}
    onChange={handleChange}
    className="w-full p-2 border rounded mt-1"
  />
</label>

          <label className="block mb-2">
            Mobile No.
            <input
              type="tel"
              name="mobileno"
              value={formData.mobileno}
              onChange={handleChange}
              placeholder="Enter your mobile number"
              className="w-full p-2 border rounded mt-1"
            />
          </label>
          <label className="block mb-2">
            Email Address
            <input
              type="email"
              name="emailid"
              value={formData.emailid}
              onChange={handleChange}
              placeholder="Enter your email address"
              className="w-full p-2 border rounded mt-1"
            />
          </label>
          <label className="block mb-2">
            Employment Type
            <select
              name="employmenttype"
              value={formData.employmenttype}
              onChange={handleChange}
              className="w-full p-2 h-10 mt-1 border rounded focus:outline-none "
            >
              <option value="">Select Employment Type</option>
              <option value="Govt. service">Govt. service</option>
              <option value="Private">Private</option>
              <option value="Unemployed">Unemployed</option>
              <option value="Retired">Retired</option>
            </select>
          </label>
          <label className="block mb-2">
            Monthly Income
            <input
              type="text"
              name="monthlyincome"
              value={formData.monthlyincome}
              onChange={handleChange}
              placeholder="Enter your monthly income"
              className="w-full p-2 border rounded mt-1"
            />
          </label>
          <label className="block mb-2">
            Employment Duration
            <div className="flex gap-2 items-center">
              <input
                type="number"
                name="employmentduration"
                value={formData.employmentduration}
                onChange={handleChange}
                placeholder="Duration"
                className="w-3/4 p-2 border rounded mt-1"
              />
              <select
                name="durationunit"
                value={formData.durationunit}
                onChange={handleChange}
                className="w-1/2 h-10 p-2 border rounded mt-1 focus:outline-none"
              >
                <option value="Months">Months</option>
                <option value="Years">Years</option>
              </select>
            </div>
          </label>
          <div className="flex justify-end gap-3 mt-4">
            <button
              type="button"
              onClick={closeModal}
              className="px-4 py-2 border border-orange-500 text-orange-500 rounded"
            >
              Cancel
            </button>
            <Button disabled={isLoading} variant="primary" type="submit">
              {isLoading ? <FiLoader size={20} className="animate-spin" /> : 'Submit'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
