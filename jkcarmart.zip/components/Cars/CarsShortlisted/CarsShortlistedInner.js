import { useEffect, useState } from "react";
import CarInfo from "../CarsData/CarInfo";
import NoRecordFound from "@/components/UI/NoRecordFound";
import styles from "./CarsShortlisted.module.css";

import { useDispatch, useSelector } from "react-redux";
import { userInterestedCarsActions } from "@/store/userInterestedCars";

import { useGetAdsQuery } from "@/store/apiServices/apiServices";


function CarsShortlistedInner() {

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(userInterestedCarsActions.fillShortlistedCars());
  }, []);

  const shortlistedCarsIds = useSelector(
    (state) => state.userInterestedCars.shortlistedCars
  );

  //const [cars, setCars] = useState([]);

  // useEffect(() => {
  //   const CarsList = JSON.parse(localStorage.getItem("CarsList"));

  //   let shortlistedCars = [];
  //   shortlistedCarsIds.forEach((shortlistedCarId) => {
  //     shortlistedCars.push(
  //       CarsList.find((element) => element.carId == shortlistedCarId)
  //     );
  //   });

  //   setCars(shortlistedCars);
  // }, [shortlistedCarsIds]);


let filterProperties="";

shortlistedCarsIds.forEach((shortlistedCarId,index) => {
  filterProperties+= `${index>0?" or ":""}ci.car_ID=${shortlistedCarId}`;
});

if(filterProperties=="" || filterProperties==undefined) filterProperties = "(ci.car_ID='empty')";

//console.log(filterProperties);

  const {data:cars,error} = useGetAdsQuery({
    filterList: [
      {
        "propertyName": filterProperties,
        "propertyVal": "",
        "operator": "",
        "conjuction": ""
      }
    ],
    paging: {
      "pageNumber": 1,
      "pageLines": 20
    },
    sortList: [
      {
        "propertyName": "salecity",
        "sortType": "asc"
      }
    ]
  });



// console.log(error);




  return (
    <div className={styles.shortlisted_cars}>
      {cars?.length > 0 ?
      cars?.map((element, i) => (
        <CarInfo carInfo={element} key={i} />
      ))
      :
      <NoRecordFound message={{heading:"No Shortlisted Car Found"}} />
      }
          
        </div>
  );
}

export default CarsShortlistedInner;
