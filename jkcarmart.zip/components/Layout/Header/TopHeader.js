import Link from "next/link";
import SearchBoxCars from "./SearchBoxCars";
import SearchBoxLocations from "./SearchBoxLocations";
import {
  FaSearch,
  FaMapMarkerAlt,
  FaRegTimesCircle,
  FaSignOutAlt,
  FaBars,
} from "react-icons/fa";

import LoginModal from "@/components/UI/LoginModal";
import Login from "@/components/Login/Login";

import { useDispatch, useSelector } from "react-redux";
import { authenticationActions } from "@/store/authentication";
import { useState } from "react";
import { HeaderHeartIcon, ProfileIcon } from "../Icons/Icons";

function TopHeader(props) {

  const [active, setActive] = useState(false);
  const [isOpen, setIsopen] = useState(false);

  const [locationSearchActive, setLocationSearchActive] = useState(false);
  const [isSidebarActive, setIsSidebarActive] = useState(false);

  const authentication = useSelector((state) => state.authentication);
  const totalShortlistedCars = useSelector(
    (state) => state.userInterestedCars.shortlistedCars.length
  );

  const dispatch = useDispatch();

  const toggleAuthenticationModel = (status) => {
    dispatch(authenticationActions.toggleAuthenticationModel(status === "open"));
  };

  const toggleSidebar = (status) => {
    setIsSidebarActive(status === "open");
  };

  const logOut = () => {
    setIsSidebarActive(false);
    dispatch(authenticationActions.loggout());
  };

  const ToggleSidebar = () => {
    setIsopen(!isOpen);
    setActive(!active);
  };

  return (
    <>
      {/* Main Header */}
      <div className="main_header relative z-10">
        <div className="container">
          <div
        className={active ? "toggle active" : "toggle"}
        onClick={ToggleSidebar}
      >
        <input type="checkbox" />
        <FaBars />
      </div>
          
          <div className="col nav_container flex items-center justify-between">
            {/* Logo */}
            <div className="logo">
              <Link href="/">
                <img src="/logo.png" width="150" alt="Logo" />
              </Link>
            </div>

            {/* Search Bar */}
            <div className="search_bar relative z-55">
              <i className="icon">
                <FaSearch color="black" />
              </i>
              <SearchBoxCars />
            </div>

            {/* My Account and Icons */}
            <div className="myaccount flex items-center space-x-4 relative z-10">
              {/* Shortlisted Cars */}
              <div
                title="Shortlisted Cars"
                className={`favourite relative ${
                  totalShortlistedCars > 0 ? "active" : ""
                }`}
              >
                <Link
                  id="Cars_Shortlisted"
                  className="user_activity_link cars_shortlisted_link"
                  href={totalShortlistedCars > 0 ? "/car/shortlisted" : "#"}
                >
                  {totalShortlistedCars > 0 && (
                    <span className="count absolute top-0 right-0 bg-red-500 text-white rounded-full text-xs px-1">
                      {totalShortlistedCars}
                    </span>
                  )}
                  <i className="icon">
                    <HeaderHeartIcon />
                  </i>
                </Link>
              </div>

              {/* Login/Profile */}
              {!authentication.isLoggedIn ? (
                <div
                  className="favourite hidden"
                  onClick={() => toggleAuthenticationModel("open")}
                >
                  <Link href="#">
                    <i className="icon">
                      <ProfileIcon />
                    </i>
                  </Link>
                </div>
              ) : (
                <Link className="my_account favourite" href="/userpanel">
                  <i className="icon z-10">
                    <ProfileIcon />
                  </i>
                </Link>
              )}

              {/* Contact */}
              <div className="header_contact">
                <span className="header_contact_text">Contact us</span>
                <Link
                  href="tel:0191-2484817"
                  className="header_contact_number gtmEvent_phoneLink_click"
                >
                  0191-2484817
                </Link>
              </div>

              {/* Location Search (Mobile) */}
              {locationSearchActive && (
                <>
                  <ul className="menu location location_mobile absolute z-30">
                    <i className="icon">
                      <FaMapMarkerAlt />
                    </i>
                    <SearchBoxLocations />
                  </ul>
                  <span
                    className="close_location_mobile absolute z-30"
                    onClick={() => setLocationSearchActive(false)}
                  >
                    <FaRegTimesCircle />
                  </span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Sidebar */}
      {isSidebarActive && (
        <div className="sidebar_overlay fixed inset-0 bg-black bg-opacity-50 z-40">
          <div className="sidebar bg-white w-80 h-full absolute top-0 right-0 z-50">
            <button
              className="close_button absolute top-2 right-2 text-xl"
              onClick={() => toggleSidebar("close")}
            >
              &times;
            </button>
            <div className="sidebar_menu p-4">
              <h2 className="text-lg font-bold mb-4">Account</h2>
              <ul className="menu_lists space-y-2">
                <li>
                  <a href="#">
                    <i className="icon">
                      <FaMapMarkerAlt />
                    </i>{" "}
                    Posted Ads
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="icon cursor-pointer">
                      <FaSignOutAlt />
                    </i>{" "}
                    Favourite
                  </a>
                </li>
              </ul>
              <span
                className="logout flex items-center mt-4 text-red-500 cursor-pointer"
                onClick={logOut}
              >
                <i className="icon mr-2">
                  <FaSignOutAlt />
                </i>{" "}
                Logout
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Login Modal */}
      {authentication.isAuthenticationModelActive && (
        <LoginModal onClose={() => toggleAuthenticationModel("close")}>
          <Login />
        </LoginModal>
      )}
    </>
  );
}

export default TopHeader;
