import React from 'react'

const index = () => {
  return (
    <div>
      car valuation
    </div>
  )
}

export default index
