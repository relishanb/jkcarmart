import '@/styles/globals.scss'

import { Provider } from 'react-redux';
import store from '../store/index';

import Integrations from './integrations/integrations';
import { ToastContainer } from 'react-toastify';

export default function App({ Component, pageProps }) {
  return (<>
  <Integrations />  
  <Provider store={store}>
    <Component {...pageProps} />
    </Provider>
  </>)
}
