function font(){
return <link href="https://fonts.googleapis.com/css?family=Poppins:700,600,500,400,300&display=swap" rel="stylesheet"></link>
}

export default font;